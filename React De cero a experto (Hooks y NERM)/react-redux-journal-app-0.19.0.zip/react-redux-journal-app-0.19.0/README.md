# JournalApp

Una aplicación para llevar mi diario hecha con React y Redux.