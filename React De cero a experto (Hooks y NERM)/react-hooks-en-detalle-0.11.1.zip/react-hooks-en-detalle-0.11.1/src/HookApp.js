import React from 'react'

export const HookApp = () => {
    return (
        <div>
            <h1>Hola Mundo</h1>
        </div>
    )
}
